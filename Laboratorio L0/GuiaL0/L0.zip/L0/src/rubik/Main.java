package rubik;
import java.util.Vector;
import rubik.busqueda.FactoriaEstrategias;
import rubik.modelo.EstadoRubik;
import rubik.modelo.OperadorRubik;
import rubik.busqueda.Operador;
import rubik.busqueda.Problema;
import rubik.modelo.Cubo;
import rubik.modelo.Movimiento;

/**
 * Interfaz a travez de la consola
 * Inteligencia Artificial 2016
 */

/**
 * Formulacion conceptual de la solucion del Cubo Rubik
 * como un problema de busqueda
 * 
 * 
 * 
 * 
 * 
 * 
 *
 */
public class Main {
     public static void main(String[] args) {
        Cubo cubo = new Cubo();
        // Describir para que son las lineas de codigo sigientes
        long semilla = 621444;       
        cubo.rnd.setSeed(semilla); 
        System.out.println("\nSEMILLA:"+semilla); 
        Vector<Movimiento> movsMezcla = cubo.mezclar(2);   
        System.out.println("\nMOVIMIENTOS:");   
        for (Movimiento m : movsMezcla) {
            System.out.print(m.toString() + " ");
        }
        System.out.println();
        System.out.println("CUBO INICIAL:\n" + cubo.toString()); 
        
        // Describir para que son las lineas de codigo sigientes
        Problema problema = new Problema(new EstadoRubik(cubo), FactoriaEstrategias.getEstrategia(3)); 
        Vector<Operador> opsSolucion = problema.obtenerSolucion();  
        System.out.println("\nSOLUCION:");
        if (opsSolucion != null) {
            for (Operador o : opsSolucion) {
                System.out.println("Accion: " + o.getEtiqueta() + " "); 
                OperadorRubik or = (OperadorRubik) o;
                cubo.mover(or.getMovimiento());
            }
            System.out.println();
            System.out.println("CUBO FINAL:\n" + cubo.toString()); 
        } else {
            System.out.println("no se ha encontrado solucion");
        }
    }
}

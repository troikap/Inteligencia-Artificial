package rubik.busqueda;

/**
 * Interfaz para encapsular Operadores
 * Inteligencia Artificial 2016
 */
public interface Operador {
    /** Etiqueta descriptiva del Operador */
    public String getEtiqueta();
}
